#' Veri setleri uzerinde agirlikli AUC ozeti (n ve ters-varyans)
#'
#' Her `signature` x `method` icin:
#' - **n-agirlikli** ortalama: `sum(n * auc) / sum(n)`
#' - **ters-varyans (IVW)** ortalama: `sum(w * auc) / sum(w)`, `w = 1 / auc_var`
#' - Heterojenlik: Cochran `Q` ve `I^2` (IVW agirliklariyla)
#'
#' Varsayilan kurallar:
#' - `independent_only = TRUE`: yalniz `independent == TRUE` (NA / FALSE dislanir)
#' - `exclude_low_coverage = TRUE`: `low_coverage == TRUE` satirlar dislanir
#' - `var_zero` / `auc_var <= 0` yalnizca IVW'den cikarilir; n-agirlikli ortalamaya girer
#' - `skipped` veya sonlu olmayan AUC satirlar yok sayilir
#'
#' DerSimonian-Laird rastgele etkili model bu fonksiyonda yoktur (opsiyonel genisleme).
#'
#' @param results `run_benchmark()` cikti tablosu.
#' @param method Belirli skorlama yontemi; `NULL` ise tum yontemler ayri ozetlenir.
#' @param include_nonindependent `TRUE` ise bagimsiz-olmayan / NA satirlar ozete girer.
#' @param independent_only `TRUE` (varsayilan) ise yalniz `independent == TRUE`.
#'   `include_nonindependent = TRUE` verilirse bu bayrak gecersiz kilinir.
#' @param exclude_var_zero `TRUE` (varsayilan) ise varyansi 0/NA olanlar IVW'den cikarilir.
#' @param exclude_low_coverage `TRUE` (varsayilan) ise dusuk kapsama satirlari ozetten cikarilir.
#'
#' @return `data.frame` ozet satirlari.
#' @export
summarize_auc <- function(results,
                          method = NULL,
                          include_nonindependent = FALSE,
                          independent_only = TRUE,
                          exclude_var_zero = TRUE,
                          exclude_low_coverage = TRUE) {
  if (!is.data.frame(results) || nrow(results) == 0L) {
    stop("`results` bos olamaz.", call. = FALSE)
  }
  req <- c("signature", "method", "dataset", "auc", "n", "skipped")
  miss <- setdiff(req, names(results))
  if (length(miss) > 0L) {
    stop("`results` eksik sutunlar: ", paste(miss, collapse = ", "), call. = FALSE)
  }

  # include_nonindependent = TRUE overrides independent_only
  if (isTRUE(include_nonindependent)) {
    independent_only <- FALSE
  }

  df <- results
  if (!is.null(method)) {
    df <- df[df$method == method, , drop = FALSE]
  }
  df <- df[!(df$skipped %in% TRUE) & is.finite(df$auc) & is.finite(df$n) & df$n > 0, , drop = FALSE]
  if (nrow(df) == 0L) {
    return(.summarize_auc_empty())
  }

  if (!"independent" %in% names(df)) {
    df$independent <- TRUE
  }
  if (!"var_zero" %in% names(df)) {
    df$var_zero <- if ("auc_var" %in% names(df)) {
      is.na(df$auc_var) | df$auc_var == 0
    } else {
      FALSE
    }
  }
  if (!"auc_var" %in% names(df)) {
    df$auc_var <- NA_real_
  }
  if (!"small_cohort" %in% names(df)) {
    df$small_cohort <- FALSE
  }
  if (!"low_coverage" %in% names(df)) {
    df$low_coverage <- FALSE
  }

  split_key <- paste(df$signature, df$method, sep = "\r")
  groups <- split(df, split_key)

  rows <- lapply(groups, function(g) {
    n_total_rows <- nrow(g)
    indep_flag <- as.logical(g$independent)
    n_small <- sum(as.logical(g$small_cohort), na.rm = TRUE)

    use_n <- g
    n_nonindep <- 0L
    if (isTRUE(independent_only)) {
      # Fail-closed: NA independent excluded from independent summary
      keep_indep <- !is.na(indep_flag) & indep_flag
      n_nonindep <- sum(!keep_indep)
      use_n <- use_n[keep_indep, , drop = FALSE]
    }

    n_low_cov <- 0L
    if (isTRUE(exclude_low_coverage) && nrow(use_n) > 0L && "low_coverage" %in% names(use_n)) {
      low_flag <- as.logical(use_n$low_coverage)
      keep_cov <- is.na(low_flag) | !low_flag
      n_low_cov <- sum(!keep_cov, na.rm = TRUE)
      use_n <- use_n[keep_cov, , drop = FALSE]
    }

    notes <- character(0)
    if (isTRUE(independent_only) && n_nonindep > 0L) {
      notes <- c(notes, sprintf("%d bagimsiz-olmayan/NA satir ozetten cikarildi", n_nonindep))
    }
    if (isTRUE(exclude_low_coverage) && n_low_cov > 0L) {
      notes <- c(notes, sprintf("%d dusuk kapsama satir ozetten cikarildi", n_low_cov))
    }
    if (n_small > 0L) {
      notes <- c(notes, sprintf("%d kucuk kohort uyarisi", n_small))
    }

    k <- nrow(use_n)
    if (k == 0L) {
      return(data.frame(
        signature = g$signature[1],
        method = g$method[1],
        n_datasets = 0L,
        n_cohorts = 0L,
        n_cohorts_ivw = 0L,
        n_total_rows = n_total_rows,
        auc_n_weighted = NA_real_,
        auc_ivw = NA_real_,
        Q = NA_real_,
        I2 = NA_real_,
        n_excluded_nonindependent = as.integer(n_nonindep),
        n_excluded_var_zero = 0L,
        n_var_zero_excluded = 0L,
        n_low_coverage_excluded = as.integer(n_low_cov),
        n_small_cohort = as.integer(n_small),
        note = paste(notes, collapse = "; "),
        stringsAsFactors = FALSE
      ))
    }

    n_vec <- as.numeric(use_n$n)
    auc_vec <- as.numeric(use_n$auc)
    auc_n <- sum(n_vec * auc_vec, na.rm = TRUE) / sum(n_vec, na.rm = TRUE)

    # P0-6: IVW ayri alt kume (var_zero / auc_var<=0 yalniz IVW'den)
    use_ivw <- use_n[
      !is.na(use_n$auc_var) & use_n$auc_var > 0 & is.finite(use_n$auc_var),
      ,
      drop = FALSE
    ]
    n_var_zero <- as.integer(k - nrow(use_ivw))
    if (isTRUE(exclude_var_zero) && n_var_zero > 0L) {
      notes <- c(notes, sprintf("%d var_zero/NA varyans satir IVW'den cikarildi", n_var_zero))
      warning(
        "Imza '", g$signature[1], "' / method '", g$method[1],
        "': varyansi 0 veya NA olan AUC'ler IVW ozetinden cikarildi (n-agirlikli ortalamaya dahil).",
        call. = FALSE
      )
    } else if (!isTRUE(exclude_var_zero)) {
      # Even if exclude_var_zero=FALSE, IVW still needs positive variance
      use_ivw <- use_n[
        !is.na(use_n$auc_var) & use_n$auc_var > 0 & is.finite(use_n$auc_var),
        ,
        drop = FALSE
      ]
      n_var_zero <- as.integer(k - nrow(use_ivw))
    }

    if (nrow(use_ivw) == 0L) {
      auc_ivw <- NA_real_
      Q <- NA_real_
      I2 <- NA_real_
      k_ivw <- 0L
    } else {
      var_vec <- as.numeric(use_ivw$auc_var)
      auc_ivw_vec <- as.numeric(use_ivw$auc)
      w <- 1 / var_vec
      auc_ivw <- sum(w * auc_ivw_vec) / sum(w)
      k_ivw <- nrow(use_ivw)
      if (k_ivw >= 2L) {
        Q <- sum(w * (auc_ivw_vec - auc_ivw)^2)
        df_q <- k_ivw - 1L
        I2 <- if (is.finite(Q) && Q > 0) {
          max(0, (Q - df_q) / Q) * 100
        } else if (is.finite(Q) && Q == 0) {
          0
        } else {
          NA_real_
        }
      } else {
        Q <- NA_real_
        I2 <- NA_real_
      }
    }

    data.frame(
      signature = g$signature[1],
      method = g$method[1],
      n_datasets = as.integer(k),
      n_cohorts = as.integer(k),
      n_cohorts_ivw = as.integer(k_ivw),
      n_total_rows = n_total_rows,
      auc_n_weighted = auc_n,
      auc_ivw = auc_ivw,
      Q = Q,
      I2 = I2,
      n_excluded_nonindependent = as.integer(n_nonindep),
      n_excluded_var_zero = as.integer(n_var_zero),
      n_var_zero_excluded = as.integer(n_var_zero),
      n_low_coverage_excluded = as.integer(n_low_cov),
      n_small_cohort = as.integer(n_small),
      note = if (length(notes) == 0L) NA_character_ else paste(notes, collapse = "; "),
      stringsAsFactors = FALSE
    )
  })

  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

.summarize_auc_empty <- function() {
  data.frame(
    signature = character(),
    method = character(),
    n_datasets = integer(),
    n_cohorts = integer(),
    n_cohorts_ivw = integer(),
    n_total_rows = integer(),
    auc_n_weighted = numeric(),
    auc_ivw = numeric(),
    Q = numeric(),
    I2 = numeric(),
    n_excluded_nonindependent = integer(),
    n_excluded_var_zero = integer(),
    n_var_zero_excluded = integer(),
    n_low_coverage_excluded = integer(),
    n_small_cohort = integer(),
    note = character(),
    stringsAsFactors = FALSE
  )
}
